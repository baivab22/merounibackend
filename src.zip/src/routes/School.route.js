import express from "express";

import SchoolController from "../controllers/school/School.controller.js";
import { authenticateUser, optionalAuthenticateUser } from "../middlewares/Auth.middleware.js";
import { authorizeRole } from "../middlewares/AuthorizeRole.js";
import { requestValidator } from "../middlewares/RequestValidator.middleware.js";
import {
    schoolPaginationSchema,
    collegeSlugParamSchema,
    updateSchoolOrderSchema,
    createOrUpdateCollegeSchema,
    collegeIdParamSchema,
} from "../validators/college/College.validator.js";
import CollegeController from "../controllers/college/College.controller.js";

const router = express.Router();

/**
 * @swagger
 * /school:
 *   get:
 *     summary: List schools
 *     tags: [Schools]
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *       - in: query
 *         name: q
 *         schema:
 *           type: string
 *         description: Search query
 *       - in: query
 *         name: is_featured
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: pinned
 *         schema:
 *           type: boolean
 *     responses:
 *       200:
 *         description: List of schools
 */
router.get(
    "/",
    optionalAuthenticateUser,
    requestValidator(schoolPaginationSchema, "query"),
    SchoolController.listSchools
);

/**
 * @swagger
 * /school/{slugs}:
 *   get:
 *     summary: Get school by slug
 *     tags: [Schools]
 *     parameters:
 *       - in: path
 *         name: slugs
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: School details
 *       404:
 *         description: School not found
 */
/**
 * @swagger
 * /school/universities:
 *   get:
 *     summary: List unique universities associated with schools
 *     tags: [Schools]
 *     responses:
 *       200:
 *         description: List of unique universities
 */
router.get("/affiliations", SchoolController.listSchoolAffiliations);
router.get("/boards", SchoolController.listSchoolBoards);
router.get("/streams", SchoolController.listSchoolStreams);


router.get(
    "/:slugs",
    requestValidator(collegeSlugParamSchema, "params"),
    SchoolController.getSchoolBySlug
);

router.patch(
    "/update-order",
    requestValidator(updateSchoolOrderSchema, "body"),
    SchoolController.updateSchoolOrder
);

/**
 * @swagger
 * /school:
 *   post:
 *     summary: Create or update a school
 *     tags: [Schools]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *     responses:
 *       201:
 *         description: School created/updated successfully
 */
router.post(
    "/",
    authenticateUser,
    authorizeRole(["admin", "editor", "agent"]),
    requestValidator(createOrUpdateCollegeSchema, "body"),
    CollegeController.createOrUpdateCollege
);

/**
 * @swagger
 * /school/save-as-draft:
 *   post:
 *     summary: Save a school as draft
 *     tags: [Schools]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     responses:
 *       200:
 *         description: School saved as draft
 */
router.post(
    "/save-as-draft",
    authenticateUser,
    authorizeRole(["admin", "editor", "agent"]),
    requestValidator(createOrUpdateCollegeSchema, "body"),
    CollegeController.saveAsDraft
);

/**
 * @swagger
 * /school/{id}:
 *   delete:
 *     summary: Delete a school
 *     tags: [Schools]
 *     security:
 *       - bearerAuth: []
 *       - cookieAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: School deleted successfully
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: School not found
 */
router.delete(
    "/:id",
    authenticateUser,
    authorizeRole(["admin", "editor"]),
    requestValidator(collegeIdParamSchema, "params"),
    CollegeController.deleteCollege
);

export default router;
